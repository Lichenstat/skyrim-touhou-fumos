Touhou Fumos for Skyrim by Lichenstat

Original Models and Textures by:
Renafox (most models) - https://sketchfab.com/kryik1023
scarletfumo (remilia model) - https://sketchfab.com/scarletfumo

Everything must be in proper working directories when loading the game,
in this case the given game is Skyrim and this mod includes meshes 
and textures.

Requirements:
Have a copy of skyrim with all dlc up to date

Installation:
Put the TouhouFumos.esp in the "(location...)/Skyrim *whatever edition*/Data" folder
of your Skyrim installation directory and copy over the meshes and textures to their 
respective folders. Activate in mod load order once in game.

Congrats, your fumos should be in game now ᗜˬᗜ
-There are currently 11 different fumos avalable.
-If a merchant of some kind sells fumos they will have one on their table near them.
-You will also be able to find them once in a while in chests around Skyrim.
-You can only get the rare Sakuya Inu fumo by finding it in a chest.
-There are 9 Reimu alternative skin fumos, one is placed in each city around skyrim,
 they are not indoors and are generally around the main pathways in the cities hidden
 in plain sight.